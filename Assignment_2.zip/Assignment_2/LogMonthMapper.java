import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogMonthMapper extends Mapper<LongWritable, Text, Text, Text>{

    @Override
    protected void map(LongWritable key, Text value,
                       Context context)
            throws IOException, InterruptedException {
        				/*
				Split the value by space
				value[0] is ip_address
				value[3] is timestamp  and removing the extra "[]" in the timestamp column

				*/
        String[] tokens = value.toString().split(" ");
        String ip_address = tokens[0];
        Date parseDate = null;
        String timest = tokens[3].replaceAll("\\[","").replaceAll("\\]","");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss");
        if(recordIsBad(timest,dateFormat))
            System.out.println("IGNORING BAD RECORD >>> ");
        else {
            //if the record is not bad will parse the timestamp and return ip_address as key and Month as value
            try {
                parseDate = dateFormat.parse(timest);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Timestamp timestamp2 = new Timestamp(parseDate.getTime());
            context.write(new Text(ip_address), new Text(new SimpleDateFormat("MMM").format(timestamp2)));
        }


    }
    /*
    This function will check if the incoming record able to parse the timestamp string if not it will return true

    */
    private boolean recordIsBad(String timest,SimpleDateFormat dateFormat){
        try {
            dateFormat.parse(timest);
            return false;
        } catch (ParseException e) {
            e.printStackTrace();
            return true;
        }

    }

}
