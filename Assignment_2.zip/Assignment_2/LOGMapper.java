import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LOGMapper extends Mapper<Object, Text, Text, Text>{

    @Override
    protected void map(Object key, Text value,
                       Context context)
            throws IOException, InterruptedException {
        String[] tokens = value.toString().split(" ");
        String ip_address = tokens[0];
        Date parseDate = null;
        String timest = tokens[3].replaceAll("\\[","").replaceAll("\\]","");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss");
        if(recordIsBad(timest,dateFormat))
            System.out.println("IGNORING BAD RECORD >>> ");
        else {
            try {
                parseDate = dateFormat.parse(timest);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Timestamp timestamp2 = new Timestamp(parseDate.getTime());
            context.write(new Text(ip_address), new Text(new SimpleDateFormat("MMM").format(timestamp2)));
        }


    }

    private boolean recordIsBad(String timest,SimpleDateFormat dateFormat){
        try {
            dateFormat.parse(timest);
            return false;
        } catch (ParseException e) {
            e.printStackTrace();
            return true;
        }

    }

}
