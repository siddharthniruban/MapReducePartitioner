import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.util.Date;

public class LOGReducer extends Reducer<Text, Text, Text, Text>{

    @Override
    protected void reduce(Text key, Iterable<Text> values,
                          Context context)
            throws IOException, InterruptedException {

      int count = 0;
        String timest = "";
                Iterator<Text> valuesIt = values.iterator();
        while(valuesIt.hasNext()){
            timest = valuesIt.next().toString();
            count++;

        }
        context.write(new Text(key), new Text(String.valueOf(count)));
    }
}
