import org.apache.hadoop.mapreduce.Partitioner;

import org.apache.hadoop.io.Text;

public class LOGPartitioner extends Partitioner<Text,Text> {
    @Override
    public int getPartition(Text key, Text value, int numReduceTasks) {
        if(numReduceTasks ==0) return 0;
        if(value.equals(new Text("Jan"))) return 1 % numReduceTasks;
        if(value.equals(new Text("Feb"))) return 2 % numReduceTasks;
        if(value.equals(new Text("Mar"))) return 3 % numReduceTasks;
        if(value.equals(new Text("Apr"))) return 4 % numReduceTasks;
        if(value.equals(new Text("May"))) return 5 % numReduceTasks;
        if(value.equals(new Text("Jun"))) return 6 % numReduceTasks;
        if(value.equals(new Text("Jul"))) return 7 % numReduceTasks;
        if(value.equals(new Text("Aug"))) return 8 % numReduceTasks;
        if(value.equals(new Text("Sep"))) return 9 % numReduceTasks;
        if(value.equals(new Text("Oct"))) return 10 % numReduceTasks;
        if(value.equals(new Text("Nov"))) return 11 % numReduceTasks;
        else return 12 % numReduceTasks;


    }
}
